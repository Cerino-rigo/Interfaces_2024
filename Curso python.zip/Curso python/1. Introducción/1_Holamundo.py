print("Hola mundo") #Imprimir en pantalla

print("Hola, bienvenidos a nuestro curso de python")

print('Hola, buenas noches')

print('Hola, bienvenidos a este "nuevo curso"')