#edad = int(input("Ingrese su edad: "))
#print("Tu edad es: ", edad)
'''
try:
    edad = int(input("Ingrese su edad: "))
    print("Tu edad es: ", edad)

except:
    print("Ingresaste un valor erroneo")


while True:
    try:
        edad = int(input("Ingrese su edad: "))
        print("Tu edad es: ", edad)
        break
    except:
        print("Ingresaste un valor erroneo")

    finally:
        print("La ejecución ha finalizado")
        


while True:
    try:
        num1 = int(input("Ingrese un número: "))
        resultado = 100/num1
        print("La división es: ", resultado)
        break
    except ZeroDivisionError:
        print("No se puede divir entre cero")


while True:
    try:
        edad = int(input("Ingrese su edad: "))
        print("Tu edad es: ", edad)
        break
    except ValueError:
        print("Ingresaste un valor erroneo")

   

while True:
    try:
        edad = int(input("Ingrese su edad: "))
        print("Tu edad es: ", edad)
        break
    except KeyboardInterrupt:
        print("\nHas cancelado la ejecución")


try:
    n = float(input("Introduce un número: "))
    5/n
except Exception as e:
    print("Ha ocurrido un error =>", type(e).__name__)

 '''

while True:
    try:
        n =float(input("Introduce un número divisor: "))
        div = 5/n
        print("El resultado es: ", div)
        break
    except ValueError:
        print("Debes introducir una cadena que sea un número")
    except ZeroDivisionError:
        print("No se puede divir entre cero, intenta con otro número")
    except Exception as e:
        print("Ha ocurrido un error no previsto", type(e).__name__)
