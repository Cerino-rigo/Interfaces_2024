num1 = 40
num2 = 99.99

print(type(num1))

print(type(num2))

#Conversión de flotante a entero

num3 = int(num2)
print(int(num2))
print(type(num3))

a = 2
b = 4.5

a = a + b #Python realiza la conversión implícita entre las variables
print(type(a))

#Conversión de entero a flotante
num3 = float(num1)
print(num3)

a = 34
b = "3.5"

#Conversión de cadena o string a flotante
b = float(b)
c = a + b

#Conversión de float a string

d = str(c)
print(d)
print(type(d))

a = "45.6"
a = float(a)

a = "python"
a = float(a)




