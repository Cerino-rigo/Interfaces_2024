diccionario = {1 : 1, 2: 2, "Hola": 7}
print(diccionario)

'''
diccionario.pop("Hola") #Eliminar datos dentro de un diccionario
print(diccionario)

diccionario.clear() #Limpiar un diccionario
print(diccionario)
'''
print(diccionario.get("Hola")) #Obener un valor del diccionario

print(diccionario.setdefault(5, 8))
print(diccionario)

diccionario2 = {6 : 10, 7 : 20}

diccionario.update(diccionario2)
print(diccionario)

dictCopy  = diccionario2.copy()
print(dictCopy)
