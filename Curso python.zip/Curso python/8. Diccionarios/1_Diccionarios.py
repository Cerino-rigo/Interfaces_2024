#Crear un diccioario: {llave o key: valor, llave o key: valor}

diccionario = {'Nombre' : "Rigo", 'Contraseña' : 12345, 'Estatura' : 1.70}
print(type(diccionario))
print(diccionario)

#No utilizar 2 claves iguales
#diccionario = {'Nombre' : "Rigo", 'Contraseña' : 12345, 'Nombre' : "Adrian"}

#print(diccionario)

print(diccionario.keys()) #Acceder a las claves o llaves

print(diccionario.values()) # Acceder a los valores

print(diccionario.items())

print(diccionario['Estatura']) #Acceder a los valores correspondientes de cada clave

diccionario['Email'] = "cerino@hotmail.com"
print(diccionario)

