
dict = {} #Crear diccionario vacío

for i in range(-10, 0):
    if i % 2 == 0: #operación módulo
        dict[i] = i ** 2
print(dict)


dict = {x:x**2 for x in range(-10, 0) if x%2 == 0}
print(dict)

dict1 = {'a': 1, 'b' : 2, 'c': 3, 'd': 4, 'e' : 5}
print(dict1)

dict_por_3 = {k:v*3 for (k,v) in dict1.items()}
print(dict_por_3)

import random
clientes = ["Rigo", "Alex", "Andrea", "Roxana", "David", "Diana"]
diccionario_descuentos = {cliente:random.randint(1, 100) for cliente in clientes}
print(diccionario_descuentos)
