lista = [7, 4, 16, 3, 8, 33, 98]
pares = filter(lambda x : x % 2 == 0  ,lista) #Aplicar filtro a la lista
print(type(pares))
print(list(pares)) #Eñs necesario convertir a lista

lista1 = [12, 42, 53, 34,  15, 2, 89, 74]
lista_pordos = []
for elemento in lista1:
    lista_pordos.append(elemento*2)
    
print(lista_pordos)

def por_dos(x):
    return x * 2

lista_xdos = map(por_dos, lista1)
print(type(lista_xdos))
print(list(lista_xdos))

lista_por2 = map(lambda x : x**3, lista1)
print(list(lista_por2))

##############################################

#Función Reduce

from functools import reduce
numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
Acumulacion = reduce(lambda acc, val: acc+val, numeros)

print(Acumulacion) # En este caso reduce devuelve un entero

from functools import reduce
personas = [
    {'Nombre': 'Alicia', 'Edad': 22},
    {'Nombre': 'Pablo', 'Edad': 36},
    {'Nombre': 'Adrian', 'Edad': 18},
    {'Nombre': 'Maria', 'Edad': 50}
]
suma_edad = reduce(lambda total, p : total + p['Edad'], personas, 0)
print("La edad promedio es: ")
print(suma_edad/len(personas))

personas1 = [
    {'Nombre': 'Alicia', 'Edad': 22, 'sexo': 'F'},
    {'Nombre': 'Pablo', 'Edad': 36, 'sexo': 'M'},
    {'Nombre': 'Adrian', 'Edad': 18, 'sexo': 'M'},
    {'Nombre': 'Maria', 'Edad': 50, 'sexo': 'F'},
    {'Nombre': 'José', 'Edad': 33, 'sexo': 'M'},
    {'Nombre': 'Arturo', 'Edad': 45, 'sexo': 'M'},
    {'Nombre': 'Ana', 'Edad': 28, 'sexo': 'F'}
]

hombres = list(filter(lambda x : x['sexo'] == 'M', personas1))
suma_edades = reduce(lambda total, p : total + p['Edad'], hombres, 0)
media_edad = suma_edades/len(hombres)

print("La lista anterior contiene los siguientes nombres masculinos: ", hombres)
print("La edad promedio de ellos es: ", media_edad)
