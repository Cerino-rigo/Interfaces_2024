def prueba (f):
    return f() #Que tenga los paréntesis significa que está por ejecutarse

def porEnviar():
    return 2+5

print(prueba(porEnviar))

def sum(m,n):
    return n + m

def multiplicacion(m, n):
    return m*n

def seleccion(operacion):
    if operacion == "suma":
        return sum
    elif operacion == "multi":
        return multiplicacion
    
op = seleccion("multi")
print(type(op))
print(op(5,8))

################

def operacion(x, fun): #Función de orden superior
    return fun(x) #elev_cuadrado(x)

def sqrt(x):
    return x**0.5

def elev_cuadrado(x):
    return x**2

print(operacion(9,elev_cuadrado))
result_1 = operacion(16,sqrt)
print(result_1)

#############

#Una función puede retornar distintos tipos de valores

def varios_tipos_de_devolucion(n):
    if(n == 1):
        return "Hello World"  #Devuelve un string
    elif(n == 2):
        return 45               #Devuelve un entero
    else: 
        return True             #Devuelve un booleano

print(varios_tipos_de_devolucion(1))



