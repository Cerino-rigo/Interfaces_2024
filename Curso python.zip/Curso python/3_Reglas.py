imprimir = 123

#print = 123
#print(print)

#Comando para conocer algunas de las palabras reservadas en python
import keyword
print(keyword.kwlist)

# No inicializar variables con un número
#30anios = 30
#print(30anios)

edad30 = 30
print(edad30)

# No nombrar variables con caracteres especiales
#ell@s = "Ellas y ellos"
#print(ell@s)

# No nombrar variables con un espacio
edad_alumnos = 23
print(edad_alumnos)

#Notación Camello

edadJovenes = 25

#Notación Serpiente
EdadJovenes = 30

Renglones = """
Bienvenidos al curso de python. El temario es el siguiente:
1. Python
2. Pandas
3. NumPy
"""

print(Renglones)


cantidadPersonas = 100
print(cantidadPersonas)

cantidadPersonas = 150
print(cantidadPersonas)

cantidadPersonas = 159
print(cantidadPersonas)

PI = 3.1416 #Constantes se denotan en mayusculas
print(PI)