num1 = 10
num2 = 3

print(num1 + num2) #Operador de suma

print(num1 - num2) #Operador de resta

print(num1 * num2) #Operador de multiplicación

print(num1 / num2) #Operador de división

print(num1 ** num2) #Operador de exponenciación

print(num1 // num2) #Operador de División entera

print(num1 % num2) #Operador de módulo

print(10 % 3) #Operador de módulo