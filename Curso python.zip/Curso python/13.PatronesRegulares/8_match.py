import re
patron = r'\d+[A-Za-z]+' #Coincidir con números que preceden a letras mayúsculas o minúsculas
cadena = "123abc456def"
coincidencia = re.match(patron, cadena)

if coincidencia:
    print("Coincidencia encontrada:", coincidencia.group())
else:
    print("No se encontró coincidencia")

numeros = ['123abc', '456def', '789ghi', 'jkl123']
patron = r'\d+' #Coincidir con uno o más dígitos

for numero in numeros:
    coincidencia = re.search(patron,numero)
    #coincidencia = re.match(patron,numero)

    if coincidencia:
        print(f"{numero} contiene un número:",coincidencia.group())
    else:
        print(f"{numero} no contiene un número")

######Compile
patron = r'\b\w+\b' #Coincidir con palabras completas
texto = "Hola mundo, este es un ejemplo"
expresion_regular = re.compile(patron) 
print(type(expresion_regular))
print(expresion_regular)

coincidencias = expresion_regular.findall(texto)
print("Coincidencias encontradas:", coincidencias)

## otro ejemplo
p = re.compile('[a-z]+')
print(p.match(" "))
print(p.match('cualquier cosa'))

#Ejemplo con finditer

patron = r'\d+'

texto = '123abc456def789'
iterador_coincidencias = re.finditer(patron, texto)
print(type(iterador_coincidencias))
print(iterador_coincidencias)
print("Coincidencias encontradas:")
for coincidencia in iterador_coincidencias:
    print(coincidencia.group())

cadenas = ["abc123def", "456xyz789", "uvm987rst", "jkl123mno"]
patron = r'[a-z]+'

for cadena in cadenas:
    iterador_coincidencias = re.finditer(patron, cadena)
    #print(iterador_coincidencias)

    print(f"Coincidencias en {cadena}")
    for coincidencia in iterador_coincidencias:
        print(coincidencia.group())