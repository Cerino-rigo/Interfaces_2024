import re
match = re.search(r'eee', 'ieee')
print(match)

print(match.group())

match = re.search(r'igs', 'ieee')
print(match)
#print(match.group())

## . = cualquier caracter menos \n
match = re.search(r'...o', 'remolinos')
print(match.group()) #Devuelve el contenido de la coincidencia 

## \d = caracter de dígito, \w caracter alfanumérico
match = re.search(r'\d\d\d', 'im456xu')
print(match)

match = re.search(r'\d{3}', 'im456xu')
print(match)

match = re.search(r'\w\w\w', '@@abcde234')
print(match)


