import re
texto = "Manzana,Plátano,Naranja,Uva"
#patron = r','
patron = r'[A-Z]'
segmentos = re.split(patron, texto)
print(segmentos)

#Coincide con cualquier elemento que no sea alfanumérico
pat = re.compile(r'\W+')
#pat = re.compile(r'(\W+)') #Incluir el separador en la lista de salida
print(pat.split('Esta es una prueba, pequeña y rápida, de split().',2))

#### Ejemplos de reemplazo

texto = "Hola, mundo. Hola, Python. Hola, a todos."
print(texto)
patron = r'Hola' #Patrón a buscar
reemplazo = 'Hola de nuevo' #Texto de reemplazo
nuevo_texto = re.sub(patron, reemplazo, texto)
print(nuevo_texto)

pat = re.compile('(azul|rojo|blanco)')
reemplazo = pat.sub('de color', 'playera azul con pantalón rojo y calzado blanco')
print(reemplazo)

reemplazo2 = pat.sub('de color', 'playera azul con pantalón rojo y calzado blanco', count=2)
print(reemplazo2)

## Ejemplo con subn

texto = "Hola, mundo. Hola, Python. Hola, a todos."
print(texto)
patron = r'Hola' #Patrón a buscar
reemplazo = 'Hola de nuevo' #Texto de reemplazo

nuevo_texto, num_reemplazos = re.subn(patron, reemplazo, texto, 2)
print("Nuevo texto:", nuevo_texto)
print("Número de reemplazos:", num_reemplazos)

texto = """
Hola, te contacto desde usuario1@gmail.com
para decirte que usuario2@yahoo.com también está interesado.
Puedes responder a usuario3@hotmail.com. Gracias
"""
patron = r'(\w+)@(\w+\.\w+)'
reemplazo = r'\1@****.***'
nuevo_texto, num_reemplazos = re.subn(patron, reemplazo, texto)
print("Nuevo texto:", nuevo_texto)
print("Número de reemplazos:", num_reemplazos)

