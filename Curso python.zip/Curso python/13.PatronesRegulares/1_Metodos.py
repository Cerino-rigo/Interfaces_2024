import re

print('word:\n\n\n')
print(r'word:\n\n\n')

str = 'Este es un ejemplo de palabra:python!!'
palabra = 'python'

match = re.search(palabra, str)
print(type(match))
print(match)

if match:
    print('Encontré la palabra:', palabra)
else:
    print('no se encontró ninguna coincidencia')

print(match.start()) # Posición donde comienza la coincidencia
print(str[30])

print(match.end())# Posición donde finaliza la coincidencia

print(match.span()) #Tupla con posiciones donde comienza y finaliza la coincidencia
print(match.string) #Devuelve la cadena donde se realizó la búsqueda