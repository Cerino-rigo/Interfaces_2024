import re
str = 'Este es un ejemplo de correo electrónico: cerinoR@hotmail.com'
#patron = r'[A-Za-z]+@[a-z]+.[a-z]+'
patron = r'\w+@\w+.\w+'

match = re.search(patron, str)
print(match)
if match:
    print('Encontré el correo:', match.group())
else:
    print("No se encontro algún correo")