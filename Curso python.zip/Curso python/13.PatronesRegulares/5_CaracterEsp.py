import re
# \d (dígitos)
patron_d = r'\d{3}'
texto_d = "123567 456 789 101122"

coin = re.search(patron_d, texto_d)
coincidencias_d = re.findall(patron_d, texto_d)
print('Coincidencias (dígitos):', coincidencias_d)
print("Coinciencias (dígitos):",coin.group())

# \w (alfanuméricos)
# y coincide con una o más repeticiones del patrón anterior (+)
patron_w = r'\w+'
texto_w = "hello world 156 amig@s"
coincidencias_w = re.findall(patron_w, texto_w)
print("Coincidencias (alfanúmericas):", coincidencias_w)

# \s (espacios en blanco)
patron_s = r'\w+\s\w+'
texto_s = "hello world open book"
coincidencias_s = re.findall(patron_s, texto_s)
print("Coincidencias (espacios en blanco):", coincidencias_s)

# \b (límite de palabra)
patron_b = r'\bword\b'
texto_b = "words word keyword"
coincidencias_b= re.findall(patron_b, texto_b)
print("Coincidencias (límites de palabras):", coincidencias_b)