import re
print(re.findall(r'[Pp]ython', 'En programación, un lenguaje versatil es Python, python permite POO'))

texto = 'abc123 DEF456'

patron1 = r'[a-z0-9]' #Coincide con letras minúsculas y dígitos

print(re.findall(patron1, texto))

patron2 = r'[A-Z0-9]'
print(re.findall(patron2, texto)) #Coincide con letras mayúsculas y dígitos

patron3 = r'[A-Za-z0-9]'
print(re.findall(patron3, texto)) #Coincide con letras mayúsculas, con letras minúsculas y dígitos

lista=re.findall(patron3, texto)
print(lista)

#Encerrar o buscar una palabra
print('Bitcoin: ', re.search(r'\bBitcoin\b \bbitcoin\b', 'Bitcoin bitcoin'))

#Inicio de la cadena
match = re.search(r'^La', 'La analítica de datos es una herramienta poderosa')
print('Principio de la cadena: ', match)

# Final de la cadena

match = re.search(r'Learning$', 'Todo esto facilita el proceso de Machine Learning')
print('Final de la cadena:', match)
