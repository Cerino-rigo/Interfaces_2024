import re

#Positive LookAhead
#Encuentra patron1 solo si le sigue patron2
patron_positivo = r'\w+(?=2)'
texto_positivo = 'abc123 def258'
coincidencias_positivo = re.findall(patron_positivo, texto_positivo)
print("Coincidencias (positive LookAhead):", coincidencias_positivo)

ejemplo = re.search(r'python(?=[a-z])', "python1234 abejaasdf")
print(ejemplo)

#print("Usando lookahead:", ejemplo.group())

#Negative Lookahead
#Encuentra patron1 solo si no le sigue patron2
patron_negativo = r'\w+\s(?!prohibido)'
texto_negativo = 'Este es un ejemplo prohibido pero no prohibido prohibido'
coincidencias_negativas = re.findall(patron_negativo, texto_negativo)
print("Coincidencias (Negative LookAhead):", coincidencias_negativas)

#Negative lookahead
ejemplo2 = re.search(r'python(?![a-z])', 'python123')
print('Negative lookahead:', ejemplo2.group())

#Positive lookbehind
#Coincide si el patrón especificado está presente antes
patron_lookbehind = r'(?<=@)\w+'
texto_lookbehind = 'user@name email@example'
coincidencias_lookbehind = re.findall(patron_lookbehind, texto_lookbehind)
print("Coincidencias (Negative LookAhead):", coincidencias_lookbehind)

#Negative lookbehind
#Coincide si el patrón especificado NO está presente antes
patron_neg_lookbehind = r'(?<!@)\w+'
texto_neg_lookbehind = 'user@name email@example'
coincidencias_neg_lookbehind = re.findall(patron_neg_lookbehind, texto_neg_lookbehind)
print("Coincidencias (Negative LookAhead):", coincidencias_neg_lookbehind)