import re
#Punto (.)
# Coincide con cualquier caracter excepto la nueva línea \n

patron_punto = r'a.b'
texto_punto = 'axb a2b a@b'
coincidencia_punto = re.findall(patron_punto, texto_punto)
print("Coincidencias (punto):", coincidencia_punto)

# Asterisco (*)
#Coincide con cero o más repeticiones del patrón anterior

patron_asterisco = r'ab*c'
textro_asterisco = "ac abc abbc abbbc bcxueas"
coincidencia_asterisco = re.findall(patron_asterisco, textro_asterisco)
print("Coincidencias (asterisco):", coincidencia_asterisco)

# Más (+)
#Coincide con una o más repeticiones del patrón anterior
patron_mas = r'ab+c'
textro_mas = "abc abbc abbbc ac"
coincidencia_mas = re.findall(patron_mas, textro_mas)
print("Coincidencias (más):", coincidencia_mas)

#Signo de interrogación (?)
#Coincide con cero o una ocurrencia del patrón anterior
patron_interrogacion = r'colou?r'
textro_interrogacion = "color colour colouur"
coincidencia_interrogacion = re.findall(patron_interrogacion, textro_interrogacion)
print("Coincidencias (más):", coincidencia_interrogacion)


print('Fecha {dd-mm-yyyy}:', re.search(r'[\d]{2}-[\d]{2}-[\d]{4}', '38-22-2024'))

texto = "31-08-2022"

#Diseño de grupos dentro del patrón
patron = r'(0[1-9]|1[0-9]|2[0-9]|3[0-1])-(0[1-9]|1[0-2])-(\d{4})'

resultado = re.search(patron, texto)
print(resultado)
print(resultado.groups()) #Devuelve las coincidencias de los grupos diseñados en el patrón

if resultado:
    print("Fecha encontrada:", resultado.group(3)) #Acceder a un grupo del patrón
else:
    print("No se encontreó ninguna fecha válida")

#Rango de repeticiones
print('Tres Dígitos:', re.search(r'[\d]{1,3}', '189 22'))

print('Tres Dígitos:', re.search(r'\d{1,3}', '189 22'))

print('Cuatro Dígitos:', re.search(r'\d{3,4}', '2154 563'))

print('Cuatro Dígitos:', re.findall(r'\d{3,4}', '2154 563 654651 23 156'))