with open("primerarchivo.txt", "r") as file:
    data = file.readlines()
    print(len(data))

with open("first_half.txt", 'w') as file1:
    for line in data[:int(len(data)/2)]:
        file1.write(line)

with open("second_half.txt", 'w') as file2:
    for line in data[int(len(data)/2):]:
        file2.write(line)
