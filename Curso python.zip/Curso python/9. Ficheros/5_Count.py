with open("Fragmento El Principito.txt", "r", encoding="utf-8") as file:
    listan = []

    texto = file.read()

    lineas = texto.splitlines() #Dividir un documento en líneas y las guarda en una lista
    print(lineas)

    print("Palabras: ")
    print(texto.count("de")) #Retorna el número de apariciones de esta palabra en el documento

num = 0
with open("Fragmento El Principito.txt", "r", encoding="utf-8") as file:
    
    for linea in file:
        palabras = linea.split() #Dividir línea en palabras
        print(palabras)
        num += len(palabras)
print(f"El total de palabras en el texto es de: {num}")






