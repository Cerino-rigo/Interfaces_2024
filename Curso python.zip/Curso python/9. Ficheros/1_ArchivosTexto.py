print("""
Manejo de archivos de texto en python y uso de métodos
      - Creación del archivo: 'primerarchivo.txt
      - Abrir archivo en modo escritura    
      """)

#Abrir archivo .txt en modo lectura (w), pero como no existe, lo crea
my_file = open('primerarchivo.txt', 'w')

print("\nEn files (a la izquierda), ya puede visualizarse el documento y el mensaje")

#Para dejar un mensaje utilizamos el método write()

my_file.write("¡Bienvenidos! a este primer archivo de texto creado desde la plataforma VS Code con código Python")
my_file.write("\nEste archivo será entretenido, pues aquí contaremos historias...")
my_file.write("\nComencemos")

print("\nAquí utilizamos el método write()")

my_file.close() #Buena práctica de programación, cerrar el archivo

##########################

#Abrir el archivo en el modo 'r', de lectura

print("\n- Abrir archivo en modo lectura")

my_file = open('primerarchivo.txt', 'r')
print(type(my_file))
print(my_file.mode)
print(my_file.read())
my_file.close()