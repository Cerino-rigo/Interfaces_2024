'''
print("\n- Abrir archivo en modo escritura, al final del archivo")

my_file = open('primerarchivo.txt', 'a')

print(my_file.writable()) #Método writeable()

my_file.write("\nEsta es una historia nunca antes contada. ")

my_file.close()
'''

my_file = open('primerarchivo.txt', 'a+')

print("\nMétodo writelines():")

my_file.writelines([" Es posible que hayan historias parecidas,", "\npero ninguna como esta. "])
print("\n Mostra el archivo con las nuevas líneas")
print(my_file.read())

my_file.close()

my_file = open('primerarchivo.txt', 'r')
print(my_file.read())

# seek() reubicar el puntero
my_file.seek(15)
print(my_file.readline())
my_file.close()
