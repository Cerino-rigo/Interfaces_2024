my_file = open('primerarchivo.txt', 'r')

#nuevo = my_file.read(15)
#print(nuevo)

#Leer una sola línea del documento
print("\nMétodo readline():")
print(my_file.readline())

print("\nMétodo readable():")
print(my_file.readable())

print("\nMétodo readlines():")
print(my_file.readlines()) #Devuelve una lista con las lineas del texto como cada uno de sus elementos

if my_file.closed:
    print("El archivo se ha cerrado correctamente")
else:
    print("El archivo permance abierto")

my_file.close()

if my_file.closed:
    print("El archivo se ha cerrado correctamente")
else:
    print("El archivo permance abierto")