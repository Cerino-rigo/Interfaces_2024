ruta = "primerarchivo.txt"

with open(ruta, mode='w', encoding="utf-8") as fichero:
    print("¡Bienvenidos! a este primer archivo de texto creado desde la plataforma VS Code con código Python 1", file=fichero)
    print("¡Bienvenidos! a este primer archivo de texto creado desde la plataforma VS Code con código Python 2", file=fichero)
    print("¡Bienvenidos! a este primer archivo de texto creado desde la plataforma VS Code con código Python 3" , file=fichero)


if fichero.closed:
    print("El archivo se ha cerrado correctamente")
else:
    print("El archivo permance abierto")

#with open(ruta, mode='w', encoding="utf-8") as fichero:
#    fichero.write("Hola\n")
'''
with open("primerarchivo.txt", "r") as file:
    for line in file:
        print(line)

        
with open("primerarchivo.txt", "r") as file:
    for line in file.readlines():
        print(line, end='')
'''

file = open("primerarchivo.txt", "r")
linea = file.readline()
while linea !='':
    print(linea)
    linea=file.readline()
file.close()

#Eliminar archivos
#import os
#os.remove("primerarchivo.txt")

