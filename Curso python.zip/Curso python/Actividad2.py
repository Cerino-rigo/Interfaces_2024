print("Introduce la cantidad de objetos que desea adquirir")

CantidadPayasos = int(input("Número de payasos: "))
CantidadMunecas = int(input("Número de muñecas: "))

Procedimiento = ((CantidadPayasos*112) + (CantidadMunecas*75))

print("El peso total de su pedido es de: {} kilogramos ".format(Procedimiento/1000))

