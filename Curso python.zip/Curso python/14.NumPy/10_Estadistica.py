import numpy as np

estadisticos = np.random.randint(100,size=(300))
print(estadisticos)

estadisticos1 = estadisticos[40:80]
print("Nuevo arreglo:\n", estadisticos1)

print("Valor máximo del arreglo:\n", estadisticos1.max())
print("Valor mínimo del arreglo:\n", estadisticos1.min())

print("Posición del valor máximo en el arreglo:\n", estadisticos1.argmax())

print("Media del arreglo:\n", estadisticos1.mean())
print("Desviación estándar del arreglo:\n", estadisticos1.std())

G = np.random.randint(1, 100, 24).reshape(6,4)
print("Arreglo G:\n", G)

##Indexación booleana
print(G>50) #Diseñar filtro

print(G[G>50]) #Aplicar filtro

print("Aplicación de filtro módulo 2:\n", G[G % 2 == 0])

#
print("Filtros combinados:\n", G[(G>50) & (G % 2 == 0)])

arr = np.random.randint(-10,10, size=(10))
print("Arreglo original:\n", arr)

#Filtrar y reemplazar elementos mayores a 5
arr[arr > 2] = 2
print("Arreglo después del filtrado:\n", arr)

arr[arr < 0] = -2
print("Arreglo después del filtrado:\n", arr)

matriz = np.random.randint(1, 10, size=(4, 4))
print("Matriz:\n", matriz)

#Suma por filas y columnas
suma_filas = np.sum(matriz, axis=1)
print("Suma por filas:\n", suma_filas)

suma_columnas = np.sum(matriz, axis=0)
print("Suma por columnas:\n", suma_columnas)

#Promedio por filas y columnas
promedio_filas= np.mean(matriz, axis=1)
print("Promedio por filas:\n",promedio_filas)
promedio_columna= np.mean(matriz, axis=0)
print("Promedio por columnas:\n",promedio_columna)

datos = np.random.randint(0, 100, size=(10))
print("Datos originales:\n", datos)

#Normalizar los datos
datos_normalizados = (datos - np.min(datos)) / (np.max(datos) - np.min(datos))
print("Datos normalizados:\n", datos_normalizados)