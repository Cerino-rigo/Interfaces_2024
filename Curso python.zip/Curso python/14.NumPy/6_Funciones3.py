import numpy as np

# Ordenar arreglo

arr = np.array([3, 2, 0, 1])

print(np.sort(arr))

arr = np.array(['banana', 'cherry', 'apple'])
print(np.sort(arr))

arr = np.array([True, False, True, False])
print(np.sort(arr))

#Ordenar arreglos 2D
arr = np.array([[3, 2, 4],[5, 0, 1]])

print(np.sort(arr))

### Delete
# np.delete(ndarray, elements, axis)
x = np.array([1, 3, 5, 7, 9])
print("Arreglo original:\n", x)
x = np.delete(x,[0, 4])
print("Arreglo modificado:\n", x)

Y = np.array([[1, 2, 3],[4, 5, 6],[7, 8, 9]])
print("Arreglo original:\n", Y)
w = np.delete(Y,0, axis=0)
print("Arreglo modificado en filas:\n", w)
v = np.delete(Y,[0,2], axis=1)
print("Arreglo modificado en columnas:\n", v)

### Append
# np.append(ndarray, elements, axis)
x = np.append(x, 12)
print("Agregar elementos a X:\n", x)

x = np.append(x, [7, 8])
print("Agregar más elementos a X:\n", x)

v = np.append(Y, [[10, 11, 12]], axis=0)
print("Agregar filas a Y:\n", v)

q = np. append(Y, [[13],[14],[15]], axis=1)
print("Agregar columnas a Y:\n", q)

#Insert
#np.insert(ndarray, index, elements,axis)
x = np.array([1, 3, 8, 6, 7])
Y = np.array([[1, 2, 3],
              [7, 8, 9]])

print("Array X:\n", x)
print("Array y:\n", Y)

x = np.insert(x, 2,[2,5])
print("Insertar elementos a 'x':\n", x)

w = np.insert(Y, 1,[4, 5, 6], axis=0)
print("Insertar filas a 'Y':\n", w)

v = np.insert(Y, 1, 5, axis=1)
print("Insertar columnas a 'Y':\n", v)

v = np.insert(Y, 2, [13, 14], axis=1)
print("Insertar columnas a 'Y':\n", v)


