import numpy as np

#Crear un arreglo unidimensional
arr = np.arange(25) #  Crear secuencia de datos
print("Arreglo unidimensional:\n", arr)

arr = np.arange(20, 100, 3) #(incio, fin, paso)
print("Arreglo que contiene una secuencia:\n", arr)

arr = np.arange(9)
print(arr)

#Transformar estructura de datos
matriz_3x3 = arr.reshape(3,3)
print("Matriz de 3x3:\n", matriz_3x3)

#Crear otra matriz
b = np.arange(1,11).reshape(2,5)
print("Matriz de 5x2:\n", b)

bT = np.arange(1,11).reshape(5,2)
print("Matriz de 5x2:\n", bT)

#Devuelve números espaciados uniformemente sobre un intervalo especificado
arr = np.linspace(25, 95, 30) # (Inicio, Fin, #elementos)
print("Arreglo que contiene una secuencia:\n", arr)

arr = np.linspace(-10, 10, 10) # (Inicio, Fin, #elementos)
print("Arreglo que contiene una secuencia:\n", arr)

## Transformar en un arreglo 1D

arr = np.zeros((5,3))
print("Arreglo de 5x3 de ceros:\n", arr)    

arr_1d = arr.flatten()
print("Arreglo 1D:", arr_1d)

arr1d = arr.ravel()
print("Arreglo 1D:", arr1d)