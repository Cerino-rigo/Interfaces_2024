import numpy as np

arr = np.array(42)
print(type(arr))

#Array de una dimensión - vectores
a1 = np.array([1, 8, 7, 5, 6])
print("Arreglo unidimensional:", a1)

#Array de dos dimensiones - matriz
a2 = np.array([[1, 8, 7],[4, 9, 8]])
print("Arreglo bidimensional:\n", a2)

#Array de tres dimensiones - Tensores
a3 = np.array([[[1, 8, 7],[4, 9, 8]], [[8, 9, 6], [10, 15, 96]]])
print("Arreglo tridimensional:\n", a3)

## Importar un ndarray utilizando una lista

l = [9, 55, 20]
arr1 = np.array(l)
print("Otro arreglo unidimensional:\n", arr1)

lista_2d = [[2, 3, 9],
            [8, 55, 12],
            [91, 23, 74]]

arr = np.array(lista_2d)
print("Otro arreglo bidimensional:\n", arr)

#### Funciones

zeros = np.zeros((3, 5)) # Crear array de ceros (Renglón x columna)
print("Matriz de ceros:\n", zeros)

#Utilizar función np.ones() para crear array de unos (Renglón x columna)
unos = np.ones((4, 4))
print("Matriz de unos:\n", unos)

#Utilizar función np.full() para crear array de constantes (Renglón x columna)
const = np.full((5, 2), 3)
print("Matriz de constantes:\n", const)

#Utilizar función np.eye() para crear matriz identidad (dimensión)
iden = np.eye(3)
print("Matriz identidad:\n", iden)

#Utilizar función np.diag() para crear matriz diagonal a partir de una lista
diag = np.diag([5, 6, 7, 8])
print("Matriz diagonal:\n", diag)

#Utilizar función np.random.random() para crear un arreglo lleno de valores aleatorios flotantes entre 0 y 1 (mxn)
aleatorios = np.random.random((4, 3))
print("Matriz aleatoria:\n", aleatorios)


#Crear dos matrices aleatorias de 2x3
matriz1 = np.random.rand(2, 3)
matriz2 = np.random.rand(2, 3)
print("Matriz 1:\n", matriz1)
print("Matriz 2:\n", matriz2)

#Apilar horizontalmente
apilado_horizontal = np.hstack((matriz1, matriz2))
print("Apilado horizontal:\n", apilado_horizontal)

#Apilar verticalmente
apilado_vertical = np.vstack((matriz1, matriz2))
print("Apilado horizontal:\n", apilado_vertical)