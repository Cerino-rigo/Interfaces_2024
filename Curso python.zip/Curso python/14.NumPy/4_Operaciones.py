import numpy as np

arr1 = np.arange(12).reshape(3,4)
print("Arreglo 1:\n", arr1)

arr2 = np.arange(12, 24).reshape(3,4)
print("Arreglo 2:\n", arr2)

#Sumar un escalar al arreglo
print("Suma de un escalar:\n", arr1+2)

#Restar un escalar al arreglo
print("Resta de un escalar:\n", arr1-2)

#Multiplicar un escalar al arreglo
print("Multiplicación de un escalar:\n", arr1*5)

#Elevar al cuadrado los elementos del arreglo
print("Arreglo elevado al cuadrado:\n", arr1**2)

##Multiplicación de matrices elemento a elemento

print("Multiplicación de matrices elemento a elemento:\n", arr1*arr2)

print("División de matrices elemento a elemento:\n", arr1/arr2)

## Producto de matrices

A = np.array([[1, 2, 3], [4, 5, 6]]) # (2x3)
B = np.array([[7, 8], [9, 10], [11, 12]]) #(3x2)

print("Matriz 1:\n", A)
print("Forma:", A.shape)
print("Matriz 2:\n", B)
print("Forma:", B.shape)

producto = np.dot(A, B)

print("Producto de matrices:\n", producto)
print("Forma:", producto.shape)

producto1 = (A @ B)
producto2 = np.matmul(A, B)

print("Producto de matrices:\n", producto1)
print("Producto de matrices:\n", producto2)

producto_inv = np.dot(B, A)
print("Producto de matrices:\n", producto_inv)

#Transpuesta de una matriz

print("Matriz A:\n", A)
print("Matriz transpuesta:\n", A.T)
print("Matriz transpuesta:\n", A.transpose())