import numpy as np

C = np.array([[11, 4, 9],
             [21, 1, -4]])

print(C)

#Máximo del arreglo
print("Máximo del arreglo:\n", np.max(C))

#Mínimo del arreglo
print("Mínimo del arreglo:\n", np.min(C))

#Sumar todos los elementos del arreglo
print("Suma de elementos del arreglo:\n", np.sum(C))

#Multiplicar todos los elementos del arreglo
print("Multiplicación de elementos del arreglo:\n", np.prod(C))

#Acceder a los ejer
# 0 = columnas, 1 = filas

print("Máximo de cada columna:\n", np.max(C, axis=0))
print("Máximo de cada fila:\n", np.max(C, axis=1))

# Concatenar

matrix1 = np.array(([[1, 2, 3],
                     [4, 5, 6]]))

matrix2 = np.array(([[7, 8, 9],
                     [10, 11, 12]]))

print("Matriz 'matrix1':\n", matrix1)
print("Matriz 'matrix2':\n", matrix2)

#Concatenar a lo largo de las columnas (axis = 0)
concatenated_matrix_rows = np.concatenate((matrix1, matrix2), axis=0)
print("Concatenación a lo largo de las columnas:\n", concatenated_matrix_rows)

#Concatenar a lo largo de las filas (axis = 1)
concatenated_matrix_cols = np.concatenate((matrix1, matrix2), axis=1)
print("Concatenación a lo largo de las columnas:\n", concatenated_matrix_cols)