import numpy as np

arr1 = np.arange(15)
print ("Arrreglo 1: \n", arr1)

arr2 = np.arange(16).reshape(4,4)
print ("Arrreglo 2: \n", arr2)

arr3 = np.arange(27).reshape(3,3,3)
print ("Arrreglo 3: \n", arr3)

print("Slicing con arreglos 1D:\n")
print(arr1[2:6]) #último valor de la derecha no incluido
#array[inicio:fin:paso]
print(arr1[2:7:2])

print("Slicing con arreglos 2D:\n")
print(arr2)

print("Acceso de la fila 2 a la 3:\n", arr2[1:3])
print("Acceso de la fila 2 a la 3 y columna 2 a la 3:\n", arr2[1:3,1:3])
#array[fila_inicio:fila_fin:paso_filas, col_inicio:col_fin:paso_col]
print("Acceso a filas y columnas particulares:\n", arr2[0:3:2,1:4:2])
print("Acceso a filas y columnas particulares:\n", arr2[::2,1::2])

print("Slicing con arreglos 3D:\n")
print(arr3)

print("Acceso a segunda matriz:\n", arr3[1])
print("Acceso a primer y última matriz:\n", arr3[::2])

print("Acceso a sugunda fila de la primer matriz:\n",arr3[0,1,:])
print("Acceso a segunda columna de la segunda matriz:\n", arr3[1,:,1])