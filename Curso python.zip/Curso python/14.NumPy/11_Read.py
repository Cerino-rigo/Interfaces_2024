import numpy as np

#Leer el archivo CSV y cargar los datos en arrays NumPy
data = np.genfromtxt('meteorologia.csv', delimiter=',', dtype=None, encoding=None, names=True)

fechas = np.array(data['Fecha'], dtype='datetime64[D]')
temp_max = np.array(data['Temp_Max'], dtype=float)
temp_min = np.array(data['Temp_Min'], dtype=float)
humedad = np.array(data['Humedad'], dtype=float)

print("Fechas:\n", fechas[:10])
data_array = np.array([(
    (row[0]),
    (row[1]),
    (row[2]),
    (row[3])
) for row in data])

print(data_array)

# Calcular el promedio de las temperaturas

promedio_temp_max = np.mean(temp_max)
promedio_temp_min = np.mean(temp_min)
print(f"Temperatura máxima promedio: {promedio_temp_max:.2f}°C")
print(f"Temperatura mínima promedio: {promedio_temp_min:.2f}°C")
promedio_temp_max2 = np.mean(data_array[:,1].astype(float))

print(f"Temperatura máxima promedio: {promedio_temp_max2:.2f}°C")

# Encontrar los días con temperaturas superiores a 30 grados
dias_temp_alta = fechas[temp_max > 30]

print(f"Días con temperaturas mayores a 30°C:\n {dias_temp_alta}")

## Calcular la desviación estándar de la humedad
desviacion_humedad = np.std(humedad)
print(f"Desviación estándar de la humedad: {desviacion_humedad:.2f}%")

# Filtrar los días donde la temperatura mínima fue mayor a 20°C y la humedad fue menor a 50%
filtro_dias = fechas[(temp_min > 20) & (humedad < 50)]
print("Diás con temperatura mínima mayor a 20°C y humedad menor a 50%:\n", filtro_dias)

#Normalizar las temperaturas
temp_max_normalizada = (temp_max - np.min(temp_max)) / (np.max(temp_max) - np.min(temp_max))
temp_min_normalizada = (temp_min - np.min(temp_min)) / (np.max(temp_min) - np.min(temp_min))

print(f"Temperaturas máximas normalizadas:\n {temp_max_normalizada[:10]}")
print(f"Temperaturas mínimas normalizadas:\n {temp_min_normalizada[:10]}")