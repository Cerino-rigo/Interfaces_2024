import numpy as np

arr1 = np.arange(15)
print ("Arrreglo 1: \n", arr1)
print("Datos recorridos:\n")
for x in arr1:
    print(x)


arr2 = np.arange(16).reshape(4,4)
print ("Arrreglo 2: \n", arr2)
print("Datos recorridos:\n")
for x in arr2:
    print(x)


arr3 = np.arange(27).reshape(3,3,3)
print ("Arrreglo 3: \n", arr3)
print("Datos recorridos:\n")
for x in arr3:
    print(x)

#Convertir un arreglo multidimensional en 1D y aplicar un ciclo
print("Conversión de arreglo multidimensional a 1D")
for x in np.nditer(arr3):
    print(x)

arr = np.array([[[1, 2, 3],[4,5,6]], [[7,8,9],[10,11,12]]])

for x in arr:
    for y in x:
        for z in y:
            print(z)