import numpy as np

arr1 = np.arange(10)
print ("Arrreglo 1: \n", arr1)

arr2 = np.arange(12).reshape(3,4)
print ("Arrreglo 2: \n", arr2)

arr3 = np.arange(8).reshape(2,2,2)
print ("Arrreglo 3: \n", arr3)

print("Indexación con arreglos 1D:\n")
#Obtener el primer elemento
print(arr1[0])
#Obtener el último elemento
print(arr1[-1])

print("Indexación con arreglos 2D:\n")
print(arr2[2,3]) # [renglón, columna]

print(arr2[1,2])

print("Indexación por filas:\n", arr2[1,:])
print("Indexación por columnas:\n", arr2[:,2])

print("Indexación con arreglos 3D:\n")
print(arr3[1, 0, 1]) #[matriz, fila, columna]

print(arr3[0,1,0])