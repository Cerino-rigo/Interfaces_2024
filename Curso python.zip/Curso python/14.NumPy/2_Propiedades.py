import numpy as np

lista_2d = [[2, 3, 9],
            [8, 55, 12],
            [91, 23, 74],
            [41, 22, 14]]

arr = np.array(lista_2d)
print(arr)

a = np.array([5, 88, 74, 12, 33])
print(a)

# Devolverr la forma del arreglo (filas x columnas)
print(arr.shape)
print(a.shape)

#Devolver el tipo de datos del arreglo
print(arr.dtype)

#Devuelve la cantidad total de datos del arreglo
print(arr.size)

#Devuelve las dimensiones del arreglo
print(arr.ndim)

#Devuelve el número de bytes utilizados para almacenar un solo elemento
print(arr.itemsize)

#Cambiando el tipo de datos

x = np.array([33, 55, 98.9])
print(x.dtype)
print(x)

x1 = x.astype(int)
print(x1.dtype)
print(x1)
