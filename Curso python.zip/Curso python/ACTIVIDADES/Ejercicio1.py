with open("Inventario.txt", 'r') as file:
    inventario = file.readlines()

#Mostrar el inventario actual
print("Inventario actual")
for linea in inventario:
    print(linea.strip())

#Solicitar al usuario el producto y la nueva cantidad

producto_a_actualizar =input("\nIntroduce el nombre del producto a actualizar: ")
nueva_cantidad = input("Introduce la nueva cantidad: ")

# Actualizar la cantidad en la lista del inventario
inventario_actualizado = []
producto_encontrado = False #Bandera auxiliar
for linea in inventario:
    producto, cantidad = linea.strip().split(':')
    #print(producto)
    #print(cantidad)
    if producto == producto_a_actualizar:
        inventario_actualizado.append(f"{producto}: {nueva_cantidad}\n")
        producto_encontrado = True  
    else:
        inventario_actualizado.append(linea)
print(inventario_actualizado)

#Verificar si el producto fue encontrado
if not producto_encontrado:
    print(f"El producto '{producto_a_actualizar}' no se encontró en el inventario.")

#Sobreescribir el archivo con la lista actualizada
with open('Inventario.txt', 'w') as file:
    file.writelines(inventario_actualizado)



