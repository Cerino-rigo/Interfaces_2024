lista = ["uno", "dos", "tres"]

for i in lista:
    print(i)

tupla = (1, 2, 3, 4, 5, 6)
for j in tupla:
    print(j)