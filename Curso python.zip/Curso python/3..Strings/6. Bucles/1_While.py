i = 0 #Elemnto iterador o el contador
'''
while i < 10:
    i += 1 # i = i+1  10
    print("Estoy iterando, voy por el salto: ", i)

print("Las iteraciones han finalizado")
'''
while i < 10:
    #9
    print("Estoy iterando, voy por el salto: ", i)
    i += 1 # i = i+1   10
print("Las iteraciones han finalizado")

