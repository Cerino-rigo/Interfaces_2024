# Range requiere 2 argumentos, en ocasiones 2
#Toma punto de inicio, Final, Recorrido

for i in range(1, 11): #Parámetro de inicio y fin
    print(i)

for i in range(10): #Parámetro de fin
    print(i)

for j in range(1, 22, 2): #Parámetro de inicio y fin, y el paso
    print(j)

frase = "Curso de python"
for caracter in frase:
    print(caracter)