for i in range(1, 11):
    print(i)
    if i == 5:
        break

for j in range(1, 11):
    if j == 6:
        continue
    print(j)