direcciones = [
    'Dirígete hacia la fuente',
    'Camina sobre la calle principal',
    'Gira a la derecha en la esquina',
    'Camina 2 calles y gira a la izquierda',
    'Gira a la derecha en la calle 8',
    'A la derecha verás tu destino'
]
#print(direcciones)

for contador, direccion in enumerate(direcciones, start=1):
    print(contador, direccion)
