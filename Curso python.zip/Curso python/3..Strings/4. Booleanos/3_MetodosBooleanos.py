cadena = "Estoy mostrando los métodos booleanos para las Strings"

print(cadena.startswith("e"))

print(cadena.endswith("s"))

print(cadena.isupper())
print(cadena.islower())