letra = "A"

#if letra == "A":
#    print("Esta vocal es la A")

if letra.lower() == "a":
    print("Esta vocal es la A")

elif letra.lower() == "e":
    print("Esta vocal es la E")

elif letra.lower() == "i":
    print("Esta vocal es la I")

elif letra.lower() == "o":
    print("Esta vocal es la O")

else:
    print("Esta vocal es la U")