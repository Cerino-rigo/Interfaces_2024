edad = 25

if edad >= 18: #Sintáxis de condicional if
    print("Eres mayor de edad. Puedes tener INE")

else:
    print("Eres menor de edad. No puedes tener INE")

print("Hasta la próxima") #Continuar con el código
