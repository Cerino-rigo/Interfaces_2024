#Operadores lógicos "and, or, not"

#AND
print(10 > 2 and 9 > 100)

print(100 > 20 & 90 > 100)

#OR
print(99 <= 230 or 60 > 10)
print(99 <= 230 | 60 > 100)

#NOT
print(not 90 != 90)
print(not (99 <= 230 or 60 > 100 ))