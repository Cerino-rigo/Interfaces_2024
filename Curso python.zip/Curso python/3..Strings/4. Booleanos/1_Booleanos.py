

num1 = 1000
num2 = 500
num3 = 1000

print(num1 > num2)

print(num1 < num2)

print(num1 >= num2)

print(num1 <= num3)

print(num1 == num3)
print(num1 == num2)

print(num1 != num2)

cadena1 = "Comparaciones de strings"
cadena2 = "Comparacion de strings"

print(cadena1 > cadena2 )