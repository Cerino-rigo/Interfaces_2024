nombre = "Rigo"
edad = 15

if nombre == "Juan":
    #print("Tú eres Juan")

    if edad >= 18:
        print("Eres Juan y eres mayor de edad")
    else:
        print("Eres Juan, pero no eres mayor de edad")

else:
    print("Tú no eres Juan, ¿Quién eres?")