cadena = """
Disfrutro progrmar en C++
C++ es facil de aprender
Llevo programando C++ 2 años
"""

print(cadena)

cadena1 = cadena.replace("C++", "Python")
print(cadena1)

cadena2 = "El lunes es el primer día de la semana. El lunes es muy productivo. Los lunes se entregan tareas"
print(cadena2)
print(cadena2.replace("lunes", "viernes",  2))