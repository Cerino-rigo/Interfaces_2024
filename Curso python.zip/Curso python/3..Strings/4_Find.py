'''
cadena = input("Inserte un dato alfanumérico: ")

if cadena.isalnum(): #Verificar si es un dato alfa numérico
    print("Has escrito una entrada válida")
else:
    print("Entrada inválida, intenta nuevamente")
'''
email = input("Digita tu email: ")
#print(email.find('@'))
#print(email.find('@',0, 5))

if email.find('@')>0 and email.find('.')>=0:
    print("Tu e-mail es {}".format(email))
else:
    print("Has digitado un e-mail no válido...")