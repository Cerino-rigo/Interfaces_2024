#Método para escapar caracteres
cadena = "Esto es un \' ejemplo de cadena de texto"
print(cadena)

cadena = "Esto es un \"ejemplo de cadena\" de texto"
print(cadena)

#Barra invertida n para salto de línea
cadena = "Esto es un \nejemplo de cadena de texto"
print(cadena)

#Barra invertida t para generar una tabulación
cadena = "Esto es un \tejemplo de cadena de texto"
print(cadena)

cadena2 = "Hola Rigo "
cadena3 = "Cerino"
numero = 2

#Concatenación de cadenas
print(cadena2 + cadena3)
print(cadena2, cadena3)

#operador de multiplicación con cadenas
print(cadena2 * 4)

print("Hola usuario: " + cadena3)
print("Hola usuario: ", cadena3)

#Concatenación de int con string
print(numero, "Hola usuario: " + cadena3)