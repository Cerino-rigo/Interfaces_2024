cadena = "Te quiero solo como amigos"

print(cadena[0 : 2])
print(cadena[-3 : ])

#Slicing print(cadena[inicio:fin:salto/paso])
print(cadena[: : 2])

print(cadena[: : -1])

print(cadena , cadena[: : -1])