cadena = " Me gusta \npython"
print(cadena)

print(cadena.split())

print(cadena.split(' '))

cadena1 = "Manzanas,Naranjas,Peras,Uvas,Fresas"
print(cadena1.split(','))

print(cadena1.split(',', 2))
cadena2 = cadena1.split(',', 2)

#Método Join

print(','.join(cadena2))
cadena3= ','.join(cadena2)

print(type(cadena3))
print(type(cadena2))

print(cadena1)
lista = list(cadena1)
print(lista)
