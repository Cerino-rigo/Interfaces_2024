cadena = "Este es un ejemplo de Substring (Devanado de cadenas)"

#Conocer la longitud de una cadena
print(len(cadena))

print(cadena[0])
print(cadena[52])

#Substrings o devanado de cadenas

print(cadena[10 : 40])

#Tomar una fracción de la cadena desde el inicio hasta el límite definido
print(cadena[ : 10])


#Tomar una fracción de la cadena desde el final hasta el límite definido
print(cadena[45 : ])

print(cadena[0])
print(cadena[-4])