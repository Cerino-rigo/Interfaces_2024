cadena = "estoy uTilizandO los Metodos de Python"

print(cadena.lower())

print(cadena.upper())

print(cadena.capitalize())

print(cadena.title())

print(cadena.swapcase())
print(cadena.upper())