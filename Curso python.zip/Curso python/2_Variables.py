#Sintaxis de la declaración de variables
#<Nombre de la variable> = <valor>

nombre = "Rigoberto Cerino"
print(type(nombre))
print(nombre)

numero = 2615
print(type(numero))
print(numero)

flotante = 3.1416
print(type(flotante))
print(flotante)

es_lunes = True
es_martes = False
print(type(es_lunes))
print(es_martes)