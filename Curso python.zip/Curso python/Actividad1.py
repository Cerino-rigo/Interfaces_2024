print("Introduzca 2 números para realizar una suma")

n1 = float(input("Número 1: "))
n2 = float(input("Número 2: "))
resultado = n1+n2
print("La suma de los dos números es: ", resultado)