def suma(**valores): #La función espera items como argumentos
    s = 0
    for key, value in valores.items():
        print(key, "=", value)
        s += value 
    return s

suma(a=3, b=10, c=8)
# suma(3, 10, 8)

print(suma(a=3, b=10, c=8))

def funcion(a, b, *args, **kwargs):
    print("a = ", a)
    print("b = ", b)
    for contador, i in enumerate(args, start=1):
        print("Elemento {} de la tupla = {}".format(contador, i))
    for key, value in kwargs.items():
        print(key, "=", value)

funcion(5, 20, 10, 12, 56, 88, 51, x='Hola', y='Que', z='Tal')

arg_tup = [1, 2, 3, 4]
arg_dic = {'x':"Hola", 'y':"Que", 'z':"Tal"}

funcion(10, 20, *arg_tup, **arg_dic)






