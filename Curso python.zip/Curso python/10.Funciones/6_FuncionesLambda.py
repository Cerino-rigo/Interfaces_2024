#Funciones lambda o anónimas
#No llevan nombre y tienen que almacenarse en una variable

#Ecuación cuadrática
polinomio = lambda x, a, b, c : a*x**2 + b*x + c #Declaración de función lambda
#Llamar a la función
print("Resolver una ecuación cuadrática en el punto solicitado: ")
print(polinomio(5, 8, 10, 1)) #Se invoca con el nombre de la variable donde se guardó

#Función lambda que se utiliza una sola vez
calc = lambda num : "Numero par" if num % 2 == 0 else "Número impar"
print(calc(10))

print((lambda a, b : a * b)(23, 55))

####################################

#Una función lambda puede ser la entrada a una función normal

def mi_funcion(lambda_func):
    return lambda_func(12, 21)

print(mi_funcion(lambda a, b : a + b)) #Pasar como argumento una función lambda

#Una función normal puede ser la entrada de una función lambda

def mi_otra_funcion(a, b):
    return a + b

print((lambda a, b : mi_otra_funcion(a,b))(78,20))

#función lambda con número de argumento indefinidos *args
print((lambda *args: sum(args))(5, 23, 45, 52, 41)) #Suma de elementos de una tupla

print((lambda **kwargs : sum(kwargs.values()))(x=23, b= 12, y = 15))

