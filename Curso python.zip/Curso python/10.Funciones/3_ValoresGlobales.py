def valores():
    global num1 #Convertir las variables a globales
    global num2
    num1 = 15 #Variables locales
    num2 = 8
    mult = num1 * num2
    return mult

print(valores())

resta = num1 - num2
print(resta)

#############################

nombre ="Juan" #Variable global

def saludo():
    nombre = "María" #Variable local
    print("Hola " + nombre)

saludo()

print("La variable global es " + nombre)