'''
def <Nombre de la función> ():
    <sentencias>
'''

'''
#Función sin parámetros
def saludo(): #Nombre de la función
    print("Hola Rigoberto Cerino") #Operaciones a ejecutar"
    print("Bienvenido al curso de Python")

#Llamar o invocar a la función
saludo()
#Llamar nuevamente a la función
saludo()

#Función con parámetro
def saludo1(nombre): #Nombre de la función(nombre del parámetro)
    print("Hola " + nombre)
    print("Bienvenido al curso de Python")

#Invocar función con argumentos
saludo1("Rigoberto Cerino Jiménez")
saludo()

'''

def tabla7():
    for i in range(11):
        print("7 x {} = {}".format(i, i*7))

tabla7()

def tablas(num):
    for i in range(11):
        print("{} x {} = {}".format(num, i, i*num))

tablas(8)
tablas(9)

