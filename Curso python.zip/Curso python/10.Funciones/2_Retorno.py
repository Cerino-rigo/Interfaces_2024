#Funciones con retorno
'''
def entero():
    print("Este es un número entero: ")
    return 10 #Return significa que la función devuelve un valor

entero()

print(entero())
num = entero()
print(num)

def decimal():
    print("Este es un número con punto decimal: ")
    return 99.99 #Return significa que la función devuelve un valor

print(decimal())

def frase():
    
    return "Mi nombre es Rigoberto Cerino" #Return significa que la función devuelve un valor

print(frase())
nombre = frase()
print(nombre)

def asignacion():
    return 1, 2, 3,4 ,5 

a, b, c, d, e = asignacion()

print(b)

for i in asignacion():
    print(i)

'''
def suma():
    num1 = 30
    num2 = 50
    suma = num1 + num2
    return suma
    
print(suma())
print(suma())

def suma1(num1, num2): #Defino la función con parámetros
    suma = num1 + num2
    print("La suma de los números es: ")
    return suma

print(suma1(21, 88)) #Aquí le indico los argumentos a la función

print(suma1(11, 55))
resultado = suma1(23, 90)
print(resultado)