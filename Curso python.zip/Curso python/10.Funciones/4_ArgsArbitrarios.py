def argumento(num):
    return type(num)

print(argumento(16))

def argumento1(*num): #La función espera una tupla de datos
    return type(num) #Retorna el tipo tupla

print(argumento1(16))

print(argumento1(16, 25, 66, 84, 12, 78)) #Llamar a la función con múltiples argumentos

def argumento2(*num):
    for i in num:
        print(i)
    return type(num)

print(argumento2(16, 20, 13, 96, 9, 52, 12))

##############################

def test_var_args(f_arg, f_arg1, *arg):
    print(type(f_arg))
    print(type(f_arg1))
    print(type(arg))
    print("Primer argumento normal: ", f_arg)
    print("Segundo argumento normal: ", f_arg1)
    for arg in arg:
        print("argumentos de *arg: ", arg)

test_var_args('Python', 'múltiples', 'argumentos')

