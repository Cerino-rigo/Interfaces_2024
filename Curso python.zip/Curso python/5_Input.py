'''
mensaje = "Ingrese un valor para la variable: " #Mensaje a presentar en pantalla
variable_entrada = input(mensaje) #Función Input para desplegar mensaje y almacenar valor

print(variable_entrada)
print(type(variable_entrada))
''' # triple comilla simple para comentar secciones de código

nombre = input("Escriba su nombre: ")
edad = input("Digite su edad: ")
estatura = input("Digite su estatura: ")

#Imprimimos los datos capturados

print(nombre, edad, estatura) #Imprimir variables en una sola línea

print('Hola', nombre, 'veo que tienes', edad, 'años')

#Método format para cadenas

print('Hola {} veo que tienes {} años'.format(nombre, edad))

print(f'Hola {nombre} veo que tienes {edad} años')


