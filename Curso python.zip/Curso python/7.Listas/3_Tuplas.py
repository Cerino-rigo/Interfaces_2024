tupla = (1, 26, 55, 90, "Rigo", 23.58)
print(type(tupla))

print(tupla[4])

#tupla[4] = "Cerino" #Una tupla es inmutable
print(tupla	)