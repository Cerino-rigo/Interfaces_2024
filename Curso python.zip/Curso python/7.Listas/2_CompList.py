cuadrados = []
[0, 1, 2, 3, 4]
for i in range(5):
    print(i**2)
    cuadrados.append(i**2)
    
print(cuadrados)

cuadrados1 = [i**2 for i in range(5)] #Comprensión de listas
print(cuadrados1)

frase = "Una persona vende cigarros en el ferrocarril"
erres = [i for i in frase if i == "r"]
print(erres)
print(len(erres))