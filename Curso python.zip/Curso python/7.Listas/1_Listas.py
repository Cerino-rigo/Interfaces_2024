'''
lista = ["Python", 100, "Nombre", 3.14, 6.24]
print(type(lista))

print(lista[-1])
print(len(lista))

lista[0]= "c++"
print(lista)

print(lista[3:6])

#Métodos con las listas

lista.append("Hola mundo") #Agregar un elemento nuevo a la lista, en la posición final
print(lista)

lista.insert(2, 650)
print(lista)


lista = [12, 65, 25, 99, 80, 36, 47, 25, 96, 25] 

print(lista.count(25))
print(lista.index(80))

lista.sort()
print(lista)

lista.reverse()
print(lista)
'''
# Métodos in / not in

lista2 =  ['t','u','t','o','r','i','a', 'l']

if 't' in lista2:
    print("La lista tiene un elemento con valor t")

else:
    print("La lista no tiene un elemento con valor t")

#not in 
if 'p' not in lista2:
    print("La lista no tiene un elemento con valor p")

else:
    print("La lista tiene un elemento con valor p")

lista3 = [11, 25, 33]
lista4 = [111, 225, 343]

listanueva = lista3 + lista4
print(listanueva)

listav = []

edad = int(input("Ingresa tu edad: "))
listav.append(edad)
print(listav)
